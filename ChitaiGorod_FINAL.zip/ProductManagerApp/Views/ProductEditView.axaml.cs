using Avalonia.Controls;
namespace ChitaiGorodApp.Views
{
    public partial class ProductEditView : UserControl
    {
        public ProductEditView() { InitializeComponent(); }
    }
}
