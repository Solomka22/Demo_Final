using Avalonia.Controls;
namespace ChitaiGorodApp.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow() { InitializeComponent(); }
    }
}
