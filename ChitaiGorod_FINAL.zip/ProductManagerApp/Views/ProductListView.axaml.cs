using Avalonia.Controls;
namespace ChitaiGorodApp.Views
{
    public partial class ProductListView : UserControl
    {
        public ProductListView() { InitializeComponent(); }
    }
}
