using Avalonia.Controls;
namespace ChitaiGorodApp.Views
{
    public partial class OrderListView : UserControl
    {
        public OrderListView() { InitializeComponent(); }
    }
}
