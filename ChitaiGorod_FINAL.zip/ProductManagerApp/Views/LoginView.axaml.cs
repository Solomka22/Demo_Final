using Avalonia.Controls;
namespace ChitaiGorodApp.Views
{
    public partial class LoginView : UserControl
    {
        public LoginView() { InitializeComponent(); }
    }
}
