using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using System.Threading.Tasks;

namespace ChitaiGorodApp.Services
{
    public enum DialogType { Info, Warning, Error, Question }

    // Сервис показа модальных окон сообщений (ошибка/предупреждение/информация).
    // Требование Модуля 3: окна с заголовком и пиктограммой.
    public static class MessageBoxService
    {
        public static async Task ShowAsync(Window owner, DialogType type, string message)
        {
            // Заголовок и значок в зависимости от типа
            (string title, string icon, IBrush color) = type switch
            {
                DialogType.Error    => ("Ошибка", "✖", Brushes.IndianRed),
                DialogType.Warning  => ("Предупреждение", "⚠", Brushes.Orange),
                DialogType.Question => ("Подтверждение", "?", Brushes.SteelBlue),
                _                   => ("Информация", "ℹ", Brushes.SteelBlue),
            };

            var dialog = new Window
            {
                Title = title,
                Width = 420,
                Height = 200,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                CanResize = false,
                FontFamily = new FontFamily("Comic Sans MS")
            };

            var iconBlock = new TextBlock
            {
                Text = icon,
                FontSize = 40,
                Foreground = color,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Avalonia.Thickness(15, 0, 15, 0)
            };

            var msgBlock = new TextBlock
            {
                Text = message,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center,
                Width = 320
            };

            var okButton = new Button
            {
                Content = "OK",
                Width = 100,
                HorizontalAlignment = HorizontalAlignment.Center,
                Background = new SolidColorBrush(Color.Parse("#546F94")),
                Foreground = Brushes.White
            };
            okButton.Click += (_, __) => dialog.Close();

            var topRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Avalonia.Thickness(10),
                Children = { iconBlock, msgBlock }
            };

            var root = new StackPanel
            {
                Margin = new Avalonia.Thickness(10),
                Spacing = 15,
                Children = { topRow, okButton }
            };

            dialog.Content = root;

            await dialog.ShowDialog(owner);
        }

        // Окно подтверждения (Да/Нет). Возвращает true если нажали Да.
        public static async Task<bool> ConfirmAsync(Window owner, string message)
        {
            bool result = false;

            var dialog = new Window
            {
                Title = "Подтверждение",
                Width = 420,
                Height = 200,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                CanResize = false,
                FontFamily = new FontFamily("Comic Sans MS")
            };

            var iconBlock = new TextBlock
            {
                Text = "?",
                FontSize = 40,
                Foreground = Brushes.SteelBlue,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Avalonia.Thickness(15, 0, 15, 0)
            };

            var msgBlock = new TextBlock
            {
                Text = message,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center,
                Width = 320
            };

            var yesButton = new Button { Content = "Да", Width = 100,
                Background = new SolidColorBrush(Color.Parse("#546F94")), Foreground = Brushes.White };
            var noButton = new Button { Content = "Нет", Width = 100 };

            yesButton.Click += (_, __) => { result = true; dialog.Close(); };
            noButton.Click += (_, __) => { result = false; dialog.Close(); };

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Spacing = 15,
                Children = { yesButton, noButton }
            };

            var topRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Avalonia.Thickness(10),
                Children = { iconBlock, msgBlock }
            };

            dialog.Content = new StackPanel
            {
                Margin = new Avalonia.Thickness(10),
                Spacing = 15,
                Children = { topRow, buttons }
            };

            await dialog.ShowDialog(owner);
            return result;
        }
    }
}
