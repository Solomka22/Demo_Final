using ChitaiGorodApp.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChitaiGorodApp.Services
{
    // Сервис доступа к базе данных. Все запросы к БД проходят здесь.
    public class DatabaseService
    {
        private readonly ChitaiGorodContext _context;
        private static readonly object _dbLock = new object();

        public DatabaseService()
        {
            _context = new ChitaiGorodContext();
        }

        // Проверка логина и пароля. Возвращает пользователя или null.
        public User? AuthenticateUser(string login, string password)
        {
            lock (_dbLock)
            {
                return _context.Users
                    .Include(u => u.Role)
                    .AsNoTracking()
                    .FirstOrDefault(u => u.Login == login && u.Password == password);
            }
        }

        // Получить все товары со связанными справочниками.
        public List<Product> GetAllProducts()
        {
            lock (_dbLock)
            {
                return _context.Products
                    .Include(p => p.Category)
                    .Include(p => p.Unit)
                    .Include(p => p.Manufacturer)
                    .Include(p => p.Supplier)
                    .AsNoTracking()
                    .ToList();
            }
        }

        // Справочники для выпадающих списков на форме товара
        public List<Category> GetCategories()
        {
            lock (_dbLock) { return _context.Categories.AsNoTracking().ToList(); }
        }

        public List<Supplier> GetSuppliers()
        {
            lock (_dbLock) { return _context.Suppliers.AsNoTracking().ToList(); }
        }

        public List<Manufacturer> GetManufacturers()
        {
            lock (_dbLock) { return _context.Manufacturers.AsNoTracking().ToList(); }
        }

        public List<Unit> GetUnits()
        {
            lock (_dbLock) { return _context.Units.AsNoTracking().ToList(); }
        }

        // Добавить товар
        public void AddProduct(Product product)
        {
            lock (_dbLock)
            {
                _context.Products.Add(product);
                _context.SaveChanges();
            }
        }

        // Обновить товар
        public void UpdateProduct(Product product)
        {
            lock (_dbLock)
            {
                var existing = _context.Products.Find(product.Article);
                if (existing == null) throw new Exception("Товар не найден");

                existing.ProductName = product.ProductName;
                existing.IdUnit = product.IdUnit;
                existing.Price = product.Price;
                existing.IdSupplier = product.IdSupplier;
                existing.IdManufacturer = product.IdManufacturer;
                existing.IdCategory = product.IdCategory;
                existing.Discount = product.Discount;
                existing.StockQuantity = product.StockQuantity;
                existing.Description = product.Description;
                existing.Photo = product.Photo;
                _context.SaveChanges();
            }
        }

        // Проверка: есть ли товар хотя бы в одном заказе
        public bool IsProductInAnyOrder(string article)
        {
            lock (_dbLock)
            {
                return _context.OrderItems.AsNoTracking().Any(oi => oi.Article == article);
            }
        }

        // Удалить товар. Бросает исключение, если товар в заказе.
        public void DeleteProduct(string article)
        {
            lock (_dbLock)
            {
                if (_context.OrderItems.Any(oi => oi.Article == article))
                    throw new InvalidOperationException(
                        "Невозможно удалить товар: он присутствует в одном или нескольких заказах.");

                var product = _context.Products.Find(article);
                if (product != null)
                {
                    _context.Products.Remove(product);
                    _context.SaveChanges();
                }
            }
        }

        // Проверка существования артикула (для добавления нового товара)
        public bool ArticleExists(string article)
        {
            lock (_dbLock)
            {
                return _context.Products.AsNoTracking().Any(p => p.Article == article);
            }
        }

        // Заказы (для менеджера/админа)
        public List<Order> GetAllOrders()
        {
            lock (_dbLock)
            {
                return _context.Orders
                    .Include(o => o.Status)
                    .Include(o => o.Point)
                    .AsNoTracking()
                    .ToList();
            }
        }
    }
}
