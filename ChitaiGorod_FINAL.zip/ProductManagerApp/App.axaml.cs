using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using ChitaiGorodApp.ViewModels;
using ChitaiGorodApp.Views;

namespace ChitaiGorodApp
{
    public partial class App : Application
    {
        // Ссылка на главное окно - нужна для показа модальных диалогов из ViewModel
        public static Window? MainWindow { get; private set; }

        public override void Initialize()
        {
            AvaloniaXamlLoader.Load(this);
        }

        public override void OnFrameworkInitializationCompleted()
        {
            if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
            {
                var window = new MainWindow
                {
                    DataContext = new MainWindowViewModel()
                };
                MainWindow = window;
                desktop.MainWindow = window;
            }
            base.OnFrameworkInitializationCompleted();
        }
    }
}
