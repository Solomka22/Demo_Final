using Avalonia.Data.Converters;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using ChitaiGorodApp.Entities;
using System;
using System.Globalization;
using System.IO;

namespace ChitaiGorodApp.Converters
{
    // Преобразует строку-путь к файлу в Bitmap для отображения в Image.
    // Без него Avalonia не покажет картинку из файловой системы.
    public class PathToBitmapConverter : IValueConverter
    {
        public static readonly PathToBitmapConverter Instance = new();

        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is string path && File.Exists(path))
            {
                try { return new Bitmap(path); }
                catch { return null; }
            }
            return null;
        }

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }
    // Возвращает цвет фона строки товара по правилам задания:
    //   нет на складе         -> серый
    //   скидка > 25%          -> #23E1EF
    //   иначе                 -> белый
    public class ProductBackgroundConverter : IValueConverter
    {
        public static readonly ProductBackgroundConverter Instance = new();

        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            if (value is Product p)
            {
                if (p.IsOutOfStock)
                    return new SolidColorBrush(Color.Parse("#D3D3D3")); // серый
                if (p.IsBigDiscount)
                    return new SolidColorBrush(Color.Parse("#23E1EF")); // бирюзовый
            }
            return Brushes.White;
        }

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }

    // Видимость элемента: true -> виден. Используется с HasDiscount.
    public class BoolToVisibleConverter : IValueConverter
    {
        public static readonly BoolToVisibleConverter Instance = new();

        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
            => value is bool b && b;

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }
}
