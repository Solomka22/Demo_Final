using System;
using System.Collections.Generic;

namespace ChitaiGorodApp.Entities;

// Заказ
public partial class Order
{
    public int IdOrder { get; set; }
    public DateTime? OrderDate { get; set; }
    public DateTime? DeliveryDate { get; set; }
    public int IdPoint { get; set; }
    public int? IdClient { get; set; }
    public string? ClientName { get; set; }
    public int? ReceiveCode { get; set; }
    public int IdStatus { get; set; }

    public virtual PickupPoint Point { get; set; } = null!;
    public virtual OrderStatus Status { get; set; } = null!;
    public virtual User? Client { get; set; }
    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
}

// Состав заказа (одна строка = один товар в заказе)
public partial class OrderItem
{
    public int IdItem { get; set; }
    public int IdOrder { get; set; }
    public string Article { get; set; } = null!;
    public int Quantity { get; set; }

    public virtual Order Order { get; set; } = null!;
    public virtual Product Product { get; set; } = null!;
}
