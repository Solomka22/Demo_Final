using System;
using System.Collections.Generic;

namespace ChitaiGorodApp.Entities;

// Пользователь системы
public partial class User
{
    public int IdUser { get; set; }
    public int IdRole { get; set; }
    public string FullName { get; set; } = null!;
    public string Login { get; set; } = null!;
    public string Password { get; set; } = null!;

    public virtual Role Role { get; set; } = null!;
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
