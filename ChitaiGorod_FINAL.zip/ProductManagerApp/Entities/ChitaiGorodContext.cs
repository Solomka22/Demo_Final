using System;
using Microsoft.EntityFrameworkCore;

namespace ChitaiGorodApp.Entities;

public partial class ChitaiGorodContext : DbContext
{
    public ChitaiGorodContext() { }
    public ChitaiGorodContext(DbContextOptions<ChitaiGorodContext> options) : base(options) { }

    public virtual DbSet<Role> Roles { get; set; }
    public virtual DbSet<Category> Categories { get; set; }
    public virtual DbSet<Unit> Units { get; set; }
    public virtual DbSet<Manufacturer> Manufacturers { get; set; }
    public virtual DbSet<Supplier> Suppliers { get; set; }
    public virtual DbSet<PickupPoint> PickupPoints { get; set; }
    public virtual DbSet<OrderStatus> OrderStatuses { get; set; }
    public virtual DbSet<User> Users { get; set; }
    public virtual DbSet<Product> Products { get; set; }
    public virtual DbSet<Order> Orders { get; set; }
    public virtual DbSet<OrderItem> OrderItems { get; set; }

    // ====================================================================
    // ⚠️ НА ЭКЗАМЕНЕ МЕНЯЙ ТОЛЬКО ЭТУ СТРОКУ:
    //   Database = путь к твоему .fdb файлу
    //   Password = пароль SYSDBA (обычно masterkey)
    // ====================================================================
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseFirebird(
            "DataSource=localhost;Port=3050;Database=/tmp/chitaigorod.fdb;Username=SYSDBA;Password=masterkey");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // === Справочники ===
        modelBuilder.Entity<Role>(e =>
        {
            e.ToTable("ROLE");
            e.HasKey(x => x.IdRole);
            e.Property(x => x.IdRole).HasColumnName("ID_ROLE");
            e.Property(x => x.RoleName).HasColumnName("ROLE_NAME").HasMaxLength(50);
        });

        modelBuilder.Entity<Category>(e =>
        {
            e.ToTable("CATEGORY");
            e.HasKey(x => x.IdCategory);
            e.Property(x => x.IdCategory).HasColumnName("ID_CATEGORY");
            e.Property(x => x.CategoryName).HasColumnName("CATEGORY_NAME").HasMaxLength(100);
        });

        modelBuilder.Entity<Unit>(e =>
        {
            e.ToTable("UNIT");
            e.HasKey(x => x.IdUnit);
            e.Property(x => x.IdUnit).HasColumnName("ID_UNIT");
            e.Property(x => x.UnitName).HasColumnName("UNIT_NAME").HasMaxLength(20);
        });

        modelBuilder.Entity<Manufacturer>(e =>
        {
            e.ToTable("MANUFACTURER");
            e.HasKey(x => x.IdManufacturer);
            e.Property(x => x.IdManufacturer).HasColumnName("ID_MANUFACTURER");
            e.Property(x => x.ManufacturerName).HasColumnName("MANUFACTURER_NAME").HasMaxLength(100);
        });

        modelBuilder.Entity<Supplier>(e =>
        {
            e.ToTable("SUPPLIER");
            e.HasKey(x => x.IdSupplier);
            e.Property(x => x.IdSupplier).HasColumnName("ID_SUPPLIER");
            e.Property(x => x.SupplierName).HasColumnName("SUPPLIER_NAME").HasMaxLength(150);
        });

        modelBuilder.Entity<PickupPoint>(e =>
        {
            e.ToTable("PICKUP_POINT");
            e.HasKey(x => x.IdPoint);
            e.Property(x => x.IdPoint).HasColumnName("ID_POINT");
            e.Property(x => x.Address).HasColumnName("ADDRESS").HasMaxLength(200);
        });

        modelBuilder.Entity<OrderStatus>(e =>
        {
            e.ToTable("ORDER_STATUS");
            e.HasKey(x => x.IdStatus);
            e.Property(x => x.IdStatus).HasColumnName("ID_STATUS");
            e.Property(x => x.StatusName).HasColumnName("STATUS_NAME").HasMaxLength(50);
        });

        // === Пользователи ===
        modelBuilder.Entity<User>(e =>
        {
            e.ToTable("USERS");
            e.HasKey(x => x.IdUser);
            e.Property(x => x.IdUser).HasColumnName("ID_USER");
            e.Property(x => x.IdRole).HasColumnName("ID_ROLE");
            e.Property(x => x.FullName).HasColumnName("FULL_NAME").HasMaxLength(150);
            e.Property(x => x.Login).HasColumnName("LOGIN").HasMaxLength(100);
            e.Property(x => x.Password).HasColumnName("PASSWORD").HasMaxLength(100);
            e.HasOne(x => x.Role).WithMany(r => r.Users).HasForeignKey(x => x.IdRole);
        });

        // === Товары ===
        modelBuilder.Entity<Product>(e =>
        {
            e.ToTable("PRODUCT");
            e.HasKey(x => x.Article);
            e.Property(x => x.Article).HasColumnName("ARTICLE").HasMaxLength(20);
            e.Property(x => x.ProductName).HasColumnName("PRODUCT_NAME").HasMaxLength(255);
            e.Property(x => x.IdUnit).HasColumnName("ID_UNIT");
            e.Property(x => x.Price).HasColumnName("PRICE").HasColumnType("DECIMAL(10,2)");
            e.Property(x => x.IdSupplier).HasColumnName("ID_SUPPLIER");
            e.Property(x => x.IdManufacturer).HasColumnName("ID_MANUFACTURER");
            e.Property(x => x.IdCategory).HasColumnName("ID_CATEGORY");
            e.Property(x => x.Discount).HasColumnName("DISCOUNT");
            e.Property(x => x.StockQuantity).HasColumnName("STOCK_QUANTITY");
            e.Property(x => x.Description).HasColumnName("DESCRIPTION");
            e.Property(x => x.Photo).HasColumnName("PHOTO").HasMaxLength(255);
            e.HasOne(x => x.Unit).WithMany(u => u.Products).HasForeignKey(x => x.IdUnit);
            e.HasOne(x => x.Supplier).WithMany(s => s.Products).HasForeignKey(x => x.IdSupplier);
            e.HasOne(x => x.Manufacturer).WithMany(m => m.Products).HasForeignKey(x => x.IdManufacturer);
            e.HasOne(x => x.Category).WithMany(c => c.Products).HasForeignKey(x => x.IdCategory);
        });

        // === Заказы ===
        modelBuilder.Entity<Order>(e =>
        {
            e.ToTable("ORDERS");
            e.HasKey(x => x.IdOrder);
            e.Property(x => x.IdOrder).HasColumnName("ID_ORDER");
            e.Property(x => x.OrderDate).HasColumnName("ORDER_DATE");
            e.Property(x => x.DeliveryDate).HasColumnName("DELIVERY_DATE");
            e.Property(x => x.IdPoint).HasColumnName("ID_POINT");
            e.Property(x => x.IdClient).HasColumnName("ID_CLIENT");
            e.Property(x => x.ClientName).HasColumnName("CLIENT_NAME").HasMaxLength(150);
            e.Property(x => x.ReceiveCode).HasColumnName("RECEIVE_CODE");
            e.Property(x => x.IdStatus).HasColumnName("ID_STATUS");
            e.HasOne(x => x.Point).WithMany(p => p.Orders).HasForeignKey(x => x.IdPoint);
            e.HasOne(x => x.Status).WithMany(s => s.Orders).HasForeignKey(x => x.IdStatus);
            e.HasOne(x => x.Client).WithMany(u => u.Orders).HasForeignKey(x => x.IdClient);
        });

        // === Состав заказа ===
        modelBuilder.Entity<OrderItem>(e =>
        {
            e.ToTable("ORDER_ITEM");
            e.HasKey(x => x.IdItem);
            e.Property(x => x.IdItem).HasColumnName("ID_ITEM");
            e.Property(x => x.IdOrder).HasColumnName("ID_ORDER");
            e.Property(x => x.Article).HasColumnName("ARTICLE").HasMaxLength(20);
            e.Property(x => x.Quantity).HasColumnName("QUANTITY");
            e.HasOne(x => x.Order).WithMany(o => o.OrderItems).HasForeignKey(x => x.IdOrder);
            e.HasOne(x => x.Product).WithMany(p => p.OrderItems).HasForeignKey(x => x.Article);
        });
    }
}
