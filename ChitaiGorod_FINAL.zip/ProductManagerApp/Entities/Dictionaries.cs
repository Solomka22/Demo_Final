using System;
using System.Collections.Generic;

namespace ChitaiGorodApp.Entities;

// Роль пользователя (Администратор / Менеджер / Авторизированный клиент)
public partial class Role
{
    public int IdRole { get; set; }
    public string RoleName { get; set; } = null!;
    public virtual ICollection<User> Users { get; set; } = new List<User>();
}

// Категория книги
public partial class Category
{
    public int IdCategory { get; set; }
    public string CategoryName { get; set; } = null!;
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}

// Единица измерения
public partial class Unit
{
    public int IdUnit { get; set; }
    public string UnitName { get; set; } = null!;
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}

// Производитель (издательство)
public partial class Manufacturer
{
    public int IdManufacturer { get; set; }
    public string ManufacturerName { get; set; } = null!;
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}

// Поставщик (в данных - автор книги)
public partial class Supplier
{
    public int IdSupplier { get; set; }
    public string SupplierName { get; set; } = null!;
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}

// Пункт выдачи заказа
public partial class PickupPoint
{
    public int IdPoint { get; set; }
    public string Address { get; set; } = null!;
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}

// Статус заказа (Новый / Завершен)
public partial class OrderStatus
{
    public int IdStatus { get; set; }
    public string StatusName { get; set; } = null!;
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
