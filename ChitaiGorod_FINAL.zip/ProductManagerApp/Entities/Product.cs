using System;
using System.Collections.Generic;
using System.IO;

namespace ChitaiGorodApp.Entities;

// Товар (книга)
public partial class Product
{
    public string Article { get; set; } = null!;
    public string ProductName { get; set; } = null!;
    public int IdUnit { get; set; }
    public decimal Price { get; set; }
    public int IdSupplier { get; set; }
    public int IdManufacturer { get; set; }
    public int IdCategory { get; set; }
    public int Discount { get; set; }
    public int StockQuantity { get; set; }
    public string? Description { get; set; }
    public string? Photo { get; set; }

    // Навигационные свойства (связи)
    public virtual Unit Unit { get; set; } = null!;
    public virtual Supplier Supplier { get; set; } = null!;
    public virtual Manufacturer Manufacturer { get; set; } = null!;
    public virtual Category Category { get; set; } = null!;
    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    // ====== ВЫЧИСЛЯЕМЫЕ СВОЙСТВА ДЛЯ ИНТЕРФЕЙСА ======

    // Цена со скидкой (итоговая)
    public decimal FinalPrice => Math.Round(Price * (1 - Discount / 100m), 2);

    // Есть ли скидка
    public bool HasDiscount => Discount > 0;

    // Нет на складе
    public bool IsOutOfStock => StockQuantity <= 0;

    // Скидка больше 25%
    public bool IsBigDiscount => Discount > 25;

    // Путь к фото (с заглушкой если файла нет)
    public string PhotoPath
    {
        get
        {
            // фото лежат в папке Assets рядом с приложением
            if (!string.IsNullOrEmpty(Photo))
            {
                var p = Path.Combine(AppContext.BaseDirectory, "Assets", Photo);
                if (File.Exists(p)) return p;
            }
            // заглушка
            return Path.Combine(AppContext.BaseDirectory, "Assets", "picture.png");
        }
    }

    // Текст с категорией и названием для шапки карточки
    public string CategoryAndName => $"{Category?.CategoryName} | {ProductName}";
}
