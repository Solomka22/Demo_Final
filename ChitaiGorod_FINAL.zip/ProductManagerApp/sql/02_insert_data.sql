-- ДАННЫЕ для БД ЧитайГород (импорт из Excel-файлов)

-- Роли
INSERT INTO ROLE (ID_ROLE, ROLE_NAME) VALUES (1, 'Администратор');
INSERT INTO ROLE (ID_ROLE, ROLE_NAME) VALUES (2, 'Менеджер');
INSERT INTO ROLE (ID_ROLE, ROLE_NAME) VALUES (3, 'Авторизированный клиент');
COMMIT;

-- Категории
INSERT INTO CATEGORY (ID_CATEGORY, CATEGORY_NAME) VALUES (1, 'Художественная литература');
INSERT INTO CATEGORY (ID_CATEGORY, CATEGORY_NAME) VALUES (2, 'Учебник для вузов');
INSERT INTO CATEGORY (ID_CATEGORY, CATEGORY_NAME) VALUES (3, 'Хрестоматия');
INSERT INTO CATEGORY (ID_CATEGORY, CATEGORY_NAME) VALUES (4, 'Учебное пособие');
COMMIT;

-- Единицы измерения
INSERT INTO UNIT (ID_UNIT, UNIT_NAME) VALUES (1, 'шт.');
COMMIT;

-- Производители (издательства)
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (1, 'Яуза');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (2, 'Т8 Издательские технологии');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (3, 'Прогресс книга');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (4, 'Время');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (5, 'Лениздат');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (6, 'Неолит');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (7, 'Амрита-Русь');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (8, 'Златоуст');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (9, 'Аспект Пресс');
INSERT INTO MANUFACTURER (ID_MANUFACTURER, MANUFACTURER_NAME) VALUES (10, 'ВКН');
COMMIT;

-- Поставщики (авторы)
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (1, 'Виктор Астафьев');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (2, 'Гилберт Кит Честертон');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (3, 'Кирилл Каланджи');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (4, 'Людмила Улицкая');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (5, 'Аркадий Гайдар');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (6, 'Юрий Родичев');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (7, 'Дэниел Джей Барретт');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (8, 'Шон Кэрролл');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (9, 'Яков Гордин');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (10, 'Иосиф Бродский');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (11, 'Янь Чуннянь Янь Чуннянь');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (12, 'Дмитрий Мережковский');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (13, 'Дмитрий Щербаков');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (14, 'Роджер Осборн, Дэн Стерджис');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (15, 'Любовь Беликова, Инна Ерофеева, Татьяна Шутова');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (16, 'Сергей Моргачев');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (17, 'Екатерина Габарта, Ирина Игнатьева');
INSERT INTO SUPPLIER (ID_SUPPLIER, SUPPLIER_NAME) VALUES (18, 'Татьяна Лопаткина, Софья Маннапова');
COMMIT;

-- Пункты выдачи
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (1, '420151, г. Лесной, ул. Вишневая, 32');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (2, '125061, г. Лесной, ул. Подгорная, 8');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (3, '630370, г. Лесной, ул. Шоссейная, 24');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (4, '400562, г. Лесной, ул. Зеленая, 32');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (5, '614510, г. Лесной, ул. Маяковского, 47');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (6, '410542, г. Лесной, ул. Светлая, 46');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (7, '620839, г. Лесной, ул. Цветочная, 8');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (8, '443890, г. Лесной, ул. Коммунистическая, 1');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (9, '603379, г. Лесной, ул. Спортивная, 46');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (10, '603721, г. Лесной, ул. Гоголя, 41');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (11, '410172, г. Лесной, ул. Северная, 13');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (12, '614611, г. Лесной, ул. Молодежная, 50');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (13, '454311, г.Лесной, ул. Новая, 19');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (14, '660007, г.Лесной, ул. Октябрьская, 19');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (15, '603036, г. Лесной, ул. Садовая, 4');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (16, '394060, г.Лесной, ул. Фрунзе, 43');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (17, '410661, г. Лесной, ул. Школьная, 50');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (18, '625590, г. Лесной, ул. Коммунистическая, 20');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (19, '625683, г. Лесной, ул. 8 Марта');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (20, '450983, г.Лесной, ул. Комсомольская, 26');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (21, '394782, г. Лесной, ул. Чехова, 3');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (22, '603002, г. Лесной, ул. Дзержинского, 28');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (23, '450558, г. Лесной, ул. Набережная, 30');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (24, '344288, г. Лесной, ул. Чехова, 1');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (25, '614164, г.Лесной,  ул. Степная, 30');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (26, '394242, г. Лесной, ул. Коммунистическая, 43');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (27, '660540, г. Лесной, ул. Солнечная, 25');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (28, '125837, г. Лесной, ул. Шоссейная, 40');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (29, '125703, г. Лесной, ул. Партизанская, 49');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (30, '625283, г. Лесной, ул. Победы, 46');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (31, '614753, г. Лесной, ул. Полевая, 35');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (32, '426030, г. Лесной, ул. Маяковского, 44');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (33, '450375, г. Лесной ул. Клубная, 44');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (34, '625560, г. Лесной, ул. Некрасова, 12');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (35, '630201, г. Лесной, ул. Комсомольская, 17');
INSERT INTO PICKUP_POINT (ID_POINT, ADDRESS) VALUES (36, '190949, г. Лесной, ул. Мичурина, 26');
COMMIT;

-- Статусы заказов
INSERT INTO ORDER_STATUS (ID_STATUS, STATUS_NAME) VALUES (1, 'Завершен');
INSERT INTO ORDER_STATUS (ID_STATUS, STATUS_NAME) VALUES (2, 'Новый');
COMMIT;

-- Пользователи
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (1, 1, 'Никифорова Анна Семеновна', '94d5ous@gmail.com', 'uzWC67');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (2, 1, 'Стелина Евгения Петровна', 'uth4iz@mail.com', '2L6KZG');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (3, 1, 'Михайлюк Анна Вячеславовна', '5d4zbu@tutanota.com', 'rwVDh9');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (4, 2, 'Ситдикова Елена Анатольевна', 'ptec8ym@yahoo.com', 'LdNyos');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (5, 2, 'Ворсин Петр Евгеньевич', '1qz4kw@mail.com', 'gynQMT');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (6, 2, 'Старикова Елена Павловна', '4np6se@mail.com', 'AtnDjr');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (7, 3, 'Никифорова Весения Николаевна', 'yzls62@outlook.com', 'JlFRCZ');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (8, 3, 'Сазонов Руслан Германович', '1diph5e@tutanota.com', '8ntwUp');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (9, 3, 'Одинцов Серафим Артёмович', 'tjde7c@yahoo.com', 'YOyhfR');
INSERT INTO USERS (ID_USER, ID_ROLE, FULL_NAME, LOGIN, PASSWORD) VALUES (10, 3, 'Степанов Михаил Артёмович', 'wpmrc3do@tutanota.com', 'RSbvHv');
COMMIT;

-- Товары (книги)
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('А112Т4', 'Прокляты и убиты', 1, 585, 1, 1, 1, 25, 6, 'Роман-эпопею "Прокляты и убиты" Виктора Астафьева по праву считают одним из самых сильных и пронзительных произведений отечественной военной прозы.', '1.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('G843H5', 'Тайны и загадки отца БраунаТайны и загадки отца Брауна', 1, 193, 2, 1, 1, 30, 9, 'Гилберт Кит Честертон — признанный классик английской литературы, один из самых ярких писателей первой половины XX века. Классикой стали его романы и многочисленные эссе, однако любовь массового читателя принесли ему рассказы об отце Брауне, тихом, застенчивом священнике, мастерски раскрывающем наиболее запутанные загадки и преступления.', '2.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('D325D4', 'Девайс', 1, 1599, 3, 2, 1, 5, 12, 'Молодой фрилансер Захар Скаро устраивается на очередную подработку. Задача, казалось бы, тривиальная: тестирование нового устройства. Вот только вопрос в том, тестированием какой реальности занимается этот новый Девайс?', '3.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('S432T5', 'Необыкновенное обыкновенное чудо. Школьные истории', 1, 549, 4, 2, 1, 15, 15, '', '4.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('F325D4', 'Чук и Гек', 1, 209, 5, 2, 1, 18, 3, 'В книгу вошли повести и рассказы Аркадия Петровича Гайдара: "Чук и Гек", "Горячий камень" и "Сказка о военной тайне, о Мальчише-Кибальчише и его твердом слове"', '5.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('G432G6', 'Информационная безопасность. Национальные стандарты Российской Федерации. 3-е издание. Учебное пособие', 1, 3899, 6, 3, 2, 22, 3, 'В учебном пособии рассмотрено более 300 действующих открытых документов национальной системы стандартизации Российской Федерации, включая международные и межгосударственные стандарты в области информационной безопасности по состоянию на начало 2023 года.', '6.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('H542F5', 'Linux. Командная строка. Лучшие практики', 1, 1799, 7, 3, 2, 4, 5, 'Перейдите на новый уровень работы в Linux! Если вы системный администратор, разработчик программного обеспечения, SRE-инженер или пользователь Linux, книга поможет вам работать быстрее, элегантнее и эффективнее.', '7.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('C346F5', 'Квантовые миры и возникновение пространства-времени', 1, 1349, 8, 3, 2, 5, 4, 'Шон Кэрролл — физик-теоретик и один из самых известных в мире популяризаторов науки — заставляет нас по-новому взглянуть на физику. Столкновение с главной загадкой квантовой механики полностью поменяет наши представления о пространстве и времени.', '8.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('F256G6', 'Вселенная. Происхождение жизни, смысл нашего существования и огромный космос', 1, 1799, 8, 3, 2, 6, 2, 'Знаменитый физик Шон Кэрролл в свойственной ему увлекательной манере объясняет принципы, которые лежат в основах научных революций от Дарвина до Эйнштейна, и показывает как невероятные научные открытия последнего столетия изменили наш мир.', '');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('J532V5', 'Пушкин. Бродский. Империя и судьба. В 2-х томах (комплект из 2-х книг)', 1, 529, 9, 4, 3, 8, 6, 'Первая книга двухтомника «Пушкин. Бродский. Империя и судьба» пронизана пушкинской темой. Пушкин — «певец империи и свободы» — присутствует даже там, где он впрямую не упоминается, ибо его судьба, как и судьба других героев книги, органично связана с трагедией великой империи.', '10.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('G643F4', 'Иосиф Бродский. Избранные эссе (комплект из 6-ти книг)', 1, 4925, 10, 5, 3, 2, 24, 'Шесть сборников избранных эссе Иосифа Бродского (1940-1996), великого поэта, драматурга, мыслителя, лауреата Нобелевской премии по литературе (1987): «Будущее или далекое прошлое», «Верь своей боли», «Как читать книгу», «О русской литературе», «О тирании», «Путеводитель по переименованному городу». Все тексты представлены на английском языке и в переводе на русский и открывают автора не только как поэта, но как историка, критика, и глубокого и ироничного мыслителя.', '11.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('J326V5', 'Тысячелетие императорской керамикиv', 1, 2599, 11, 5, 3, 5, 4, 'Фарфор стал величайшим символом китайской культуры. Это одно из выдающихся изобретений, внесших неоценимый вклад в мировую цивилизацию.', '12.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('J632F6', 'Вечные спутники: Портреты из всемирной литературы', 1, 1599, 12, 5, 3, 0, 6, 'Книга "Вечные спутники" - это цикл критических очерков о культуре и великих литераторах, сопровождавших жизнь и творчество русского писателя, поэта, литературного критика и общественного деятеля Дмитрия Мережковского (1865–1941).', '13.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('G632H6', 'Формирование литературной репутации Н.Г.Чернышевского в ХIX-XXI веках', 1, 1349, 13, 6, 3, 2, 8, 'Монография Д. А. Щербакова - новаторская. Поэтапно рассмотрены не только многочисленные суждения известных отечественных и зарубежных критиков, литературоведов, философов и политиков, различным образом характеризовавших Н. Г. Чернышевского в связи и вне связи со знаменитым романом "Что делать?', '14.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('M642E5', 'Теория искусства. Краткий путеводитель', 1, 879, 14, 6, 3, 3, 2, '', '15.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('G543F5', 'Религиозные верования с древнейших времен до наших дней', 1, 879, 13, 7, 3, 4, 6, 'Настоящее издание представляет собой сборник переводов лекций по истории дохристианских и нехристианских религий, прочитанных в Лондоне в период с 1888 по 1891 гг. авторитетными исследователями данного раздела религиоведения.', '16.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('B653G6', 'Русский язык: Первые шаги. Часть 3. Учебное пособие', 1, 2699, 15, 8, 4, 8, 9, 'Пособие является завершающей частью учебного комплекса. Третья часть содержит 10 уроков (21-30, последний-повторительный). Усвоение лексико-грамматического материала рассчитано примерно на 200-240 часов аудиторных занятий.', '17.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('J735J7', 'Синтетический образ индивидуального психического мира', 1, 1099, 16, 8, 3, 9, 4, 'Психика подобна определенным объектам, это фиксируют сами люди в языке и искусстве. В данном исследовании рассматриваются в этом плане образы сосуда, воронки, дерева и крепости.', '18.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('H436H7', 'Английский язык в спорте: Учебное пособие', 1, 1999, 17, 9, 4, 2, 0, 'Учебное пособие подготовлено для слушателей, изу чающих английский язык как язык специальности', '19.jpg');
INSERT INTO PRODUCT (ARTICLE, PRODUCT_NAME, ID_UNIT, PRICE, ID_SUPPLIER, ID_MANUFACTURER, ID_CATEGORY, DISCOUNT, STOCK_QUANTITY, DESCRIPTION, PHOTO) VALUES ('H475R5', 'Лексика и грамматика современного китайского языка (к тому II учебника «Новый практический курс китайского языка» под редакцией Лю Сюня): учебное пособие', 1, 608, 18, 10, 4, 25, 12, 'Пособие выступает дополнением ко второму тому учебника «Новый практический курс китайского языка» (под редакцией Лю Сюня).', '20.jpg');
COMMIT;
