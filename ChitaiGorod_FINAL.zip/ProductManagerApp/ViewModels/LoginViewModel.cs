using ChitaiGorodApp.Services;
using ReactiveUI;
using System;
using System.Reactive;

namespace ChitaiGorodApp.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly MainWindowViewModel _main;
        private readonly DatabaseService _db;

        private string _login = string.Empty;
        private string _password = string.Empty;
        private string _error = string.Empty;
        private bool _isPasswordVisible;

        public LoginViewModel(MainWindowViewModel main)
        {
            _main = main;
            _db = new DatabaseService();

            LoginCommand = ReactiveCommand.Create(ExecuteLogin);
            GuestCommand = ReactiveCommand.Create(() => _main.LoginAsGuest());
            TogglePasswordCommand = ReactiveCommand.Create(() => { IsPasswordVisible = !IsPasswordVisible; });

            // обновляем зависимые свойства при переключении видимости пароля
            this.WhenAnyValue(x => x.IsPasswordVisible).Subscribe(_ =>
            {
                this.RaisePropertyChanged(nameof(PasswordChar));
                this.RaisePropertyChanged(nameof(ToggleText));
            });
        }

        public string Login { get => _login; set => this.RaiseAndSetIfChanged(ref _login, value); }
        public string Password { get => _password; set => this.RaiseAndSetIfChanged(ref _password, value); }
        public string Error { get => _error; set => this.RaiseAndSetIfChanged(ref _error, value); }

        public bool IsPasswordVisible
        {
            get => _isPasswordVisible;
            set => this.RaiseAndSetIfChanged(ref _isPasswordVisible, value);
        }

        // null = показать текст, '*' = скрыть
        public char? PasswordChar => IsPasswordVisible ? (char?)null : '*';
        public string ToggleText => IsPasswordVisible ? "Скрыть" : "Показать";

        public ReactiveCommand<Unit, Unit> LoginCommand { get; }
        public ReactiveCommand<Unit, Unit> GuestCommand { get; }
        public ReactiveCommand<Unit, Unit> TogglePasswordCommand { get; }

        private void ExecuteLogin()
        {
            Error = string.Empty;

            // Проверка заполнения полей
            if (string.IsNullOrWhiteSpace(Login) || string.IsNullOrWhiteSpace(Password))
            {
                Error = "Введите логин и пароль.";
                return;
            }

            try
            {
                var user = _db.AuthenticateUser(Login.Trim(), Password);
                if (user != null)
                {
                    _main.LoginAs(user);
                }
                else
                {
                    Error = "Неверный логин или пароль.";
                }
            }
            catch (Exception ex)
            {
                Error = $"Ошибка подключения к базе данных: {ex.Message}";
            }
        }
    }
}
