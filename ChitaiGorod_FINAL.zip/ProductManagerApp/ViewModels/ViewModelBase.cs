using ReactiveUI;

namespace ChitaiGorodApp.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
