using ChitaiGorodApp.Entities;
using ReactiveUI;

namespace ChitaiGorodApp.ViewModels
{
    // Главный навигатор: переключает экраны и хранит текущего пользователя.
    public class MainWindowViewModel : ViewModelBase
    {
        private ViewModelBase _content = null!;

        public MainWindowViewModel()
        {
            ShowLogin();
        }

        public ViewModelBase Content
        {
            get => _content;
            private set => this.RaiseAndSetIfChanged(ref _content, value);
        }

        // Текущий пользователь (null = гость)
        public User? CurrentUser { get; private set; }

        // ФИО в правом верхнем углу (требование задания)
        private string _userDisplayName = "Гость";
        public string UserDisplayName
        {
            get => _userDisplayName;
            private set => this.RaiseAndSetIfChanged(ref _userDisplayName, value);
        }

        public void ShowLogin()
        {
            CurrentUser = null;
            UserDisplayName = "Гость";
            Content = new LoginViewModel(this);
        }

        // Вход как авторизованный пользователь
        public void LoginAs(User user)
        {
            CurrentUser = user;
            UserDisplayName = user.FullName;
            Content = new ProductListViewModel(this, user.Role.RoleName, user.FullName);
        }

        // Вход как гость (без авторизации)
        public void LoginAsGuest()
        {
            CurrentUser = null;
            UserDisplayName = "Гость";
            Content = new ProductListViewModel(this, "Гость", "Гость");
        }

        // Открыть форму добавления товара
        public void ShowAddProduct()
        {
            Content = new ProductEditViewModel(this, null);
        }

        // Открыть форму редактирования товара
        public void ShowEditProduct(Product product)
        {
            Content = new ProductEditViewModel(this, product);
        }

        // Вернуться к списку товаров (после добавления/редактирования или из заказов)
        public void BackToProductList()
        {
            string role = CurrentUser?.Role.RoleName ?? "Гость";
            string name = CurrentUser?.FullName ?? "Гость";
            Content = new ProductListViewModel(this, role, name);
        }

        // Показать заказы (менеджер/админ)
        public void ShowOrders()
        {
            Content = new OrderListViewModel(this);
        }
    }
}
