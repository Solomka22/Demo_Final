using ChitaiGorodApp.Entities;
using ChitaiGorodApp.Services;
using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using RUnit = System.Reactive.Unit;

namespace ChitaiGorodApp.ViewModels
{
    public class ProductListViewModel : ViewModelBase
    {
        private readonly MainWindowViewModel _main;
        private readonly DatabaseService _db;
        private readonly string _role;

        // Полный список товаров из БД (кэш) и отображаемый (отфильтрованный)
        private List<Product> _allProducts = new();
        private ObservableCollection<Product> _products = new();

        private string _search = string.Empty;
        private int _sortIndex;       // индекс выбранной сортировки
        private int _discountIndex;   // индекс выбранного диапазона скидки

        public ProductListViewModel(MainWindowViewModel main, string role, string userName)
        {
            _main = main;
            _db = new DatabaseService();
            _role = role;
            UserName = userName;

            LogoutCommand = ReactiveCommand.Create(() => _main.ShowLogin());
            AddProductCommand = ReactiveCommand.Create(() => _main.ShowAddProduct());
            EditProductCommand = ReactiveCommand.Create<Product>(p => { if (p != null) _main.ShowEditProduct(p); });
            DeleteProductCommand = ReactiveCommand.CreateFromTask<Product>(DeleteAsync);
            ShowOrdersCommand = ReactiveCommand.Create(() => _main.ShowOrders());

            // Поиск/сортировка/фильтр - в реальном времени (без кнопки)
            this.WhenAnyValue(x => x.Search).Subscribe(_ => ApplyFilters());
            this.WhenAnyValue(x => x.SortIndex).Subscribe(_ => ApplyFilters());
            this.WhenAnyValue(x => x.DiscountIndex).Subscribe(_ => ApplyFilters());

            LoadProducts();
        }

        public string UserName { get; }

        // Роль определяет, что показывать в интерфейсе
        public bool IsManager => _role == "Менеджер";
        public bool IsAdmin => _role == "Администратор";
        // Поиск/сортировка/фильтр доступны менеджеру и админу
        public bool CanUseTools => IsManager || IsAdmin;
        // Заказы видят менеджер и админ
        public bool CanViewOrders => IsManager || IsAdmin;

        public ObservableCollection<Product> Products
        {
            get => _products;
            private set => this.RaiseAndSetIfChanged(ref _products, value);
        }

        public string Search { get => _search; set => this.RaiseAndSetIfChanged(ref _search, value); }
        public int SortIndex { get => _sortIndex; set => this.RaiseAndSetIfChanged(ref _sortIndex, value); }
        public int DiscountIndex { get => _discountIndex; set => this.RaiseAndSetIfChanged(ref _discountIndex, value); }

        // Варианты сортировки (по цене и количеству, возр/убыв)
        public string[] SortOptions => new[]
        {
            "Без сортировки",
            "Цена (возрастание)",
            "Цена (убывание)",
            "Количество (возрастание)",
            "Количество (убывание)"
        };

        // Диапазоны скидок. Первый - "Все диапазоны" (сброс).
        public string[] DiscountOptions => new[]
        {
            "Все диапазоны",
            "0-12,99%",
            "13-16,99%",
            "17% и более"
        };

        public ReactiveCommand<RUnit, RUnit> LogoutCommand { get; }
        public ReactiveCommand<RUnit, RUnit> AddProductCommand { get; }
        public ReactiveCommand<Product, RUnit> EditProductCommand { get; }
        public ReactiveCommand<Product, RUnit> DeleteProductCommand { get; }
        public ReactiveCommand<RUnit, RUnit> ShowOrdersCommand { get; }

        private void LoadProducts()
        {
            try
            {
                _allProducts = _db.GetAllProducts();
                ApplyFilters();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка загрузки товаров: {ex.Message}");
            }
        }

        // Применяет поиск + фильтр + сортировку вместе (требование задания).
        private void ApplyFilters()
        {
            IEnumerable<Product> q = _allProducts;

            // Гость и авторизованный клиент видят список без инструментов -
            // фильтры к ним не применяем
            if (CanUseTools)
            {
                // Поиск по всем текстовым полям одновременно
                if (!string.IsNullOrWhiteSpace(Search))
                {
                    string s = Search.Trim().ToLower();
                    q = q.Where(p =>
                        (p.ProductName ?? "").ToLower().Contains(s) ||
                        (p.Article ?? "").ToLower().Contains(s) ||
                        (p.Description ?? "").ToLower().Contains(s) ||
                        (p.Category?.CategoryName ?? "").ToLower().Contains(s) ||
                        (p.Supplier?.SupplierName ?? "").ToLower().Contains(s) ||
                        (p.Manufacturer?.ManufacturerName ?? "").ToLower().Contains(s));
                }

                // Фильтр по диапазону скидки
                q = DiscountIndex switch
                {
                    1 => q.Where(p => p.Discount >= 0 && p.Discount < 13),    // 0-12,99%
                    2 => q.Where(p => p.Discount >= 13 && p.Discount < 17),   // 13-16,99%
                    3 => q.Where(p => p.Discount >= 17),                      // 17% и более
                    _ => q                                                    // Все диапазоны
                };

                // Сортировка (сохраняется вместе с поиском и фильтром)
                q = SortIndex switch
                {
                    1 => q.OrderBy(p => p.Price),
                    2 => q.OrderByDescending(p => p.Price),
                    3 => q.OrderBy(p => p.StockQuantity),
                    4 => q.OrderByDescending(p => p.StockQuantity),
                    _ => q
                };
            }

            Products = new ObservableCollection<Product>(q.ToList());
        }

        // Удаление товара (только админ). Нельзя удалить товар из заказа.
        private async System.Threading.Tasks.Task DeleteAsync(Product product)
        {
            if (product == null) return;

            var owner = App.MainWindow;
            if (owner == null) return;

            // Подтверждение необратимой операции
            bool confirmed = await MessageBoxService.ConfirmAsync(owner,
                $"Вы действительно хотите удалить товар \"{product.ProductName}\"?");
            if (!confirmed) return;

            try
            {
                _db.DeleteProduct(product.Article);
                await MessageBoxService.ShowAsync(owner, DialogType.Info, "Товар успешно удалён.");
                LoadProducts(); // обновляем список после удаления
            }
            catch (InvalidOperationException ex)
            {
                // товар в заказе - удалять нельзя
                await MessageBoxService.ShowAsync(owner, DialogType.Warning, ex.Message);
            }
            catch (Exception ex)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Error, $"Ошибка удаления: {ex.Message}");
            }
        }
    }
}
