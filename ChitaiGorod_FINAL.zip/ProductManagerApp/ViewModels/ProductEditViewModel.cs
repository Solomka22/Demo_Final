using ChitaiGorodApp.Entities;
using ChitaiGorodApp.Services;
using ReactiveUI;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using RUnit = System.Reactive.Unit;

namespace ChitaiGorodApp.ViewModels
{
    // Форма добавления (product == null) или редактирования товара.
    public class ProductEditViewModel : ViewModelBase
    {
        private readonly MainWindowViewModel _main;
        private readonly DatabaseService _db;
        private readonly Product? _editing;   // null = режим добавления

        private string _article = string.Empty;
        private string _name = string.Empty;
        private string _description = string.Empty;
        private string _priceText = string.Empty;
        private string _discountText = "0";
        private string _stockText = "0";
        private string _photo = string.Empty;
        private Category? _selectedCategory;
        private Supplier? _selectedSupplier;
        private Manufacturer? _selectedManufacturer;
        private Unit? _selectedUnit;

        public ProductEditViewModel(MainWindowViewModel main, Product? product)
        {
            _main = main;
            _db = new DatabaseService();
            _editing = product;

            // Загружаем справочники для выпадающих списков
            Categories = _db.GetCategories();
            Suppliers = _db.GetSuppliers();
            Manufacturers = _db.GetManufacturers();
            Units = _db.GetUnits();

            SaveCommand = ReactiveCommand.CreateFromTask(SaveAsync);
            BackCommand = ReactiveCommand.Create(() => _main.BackToProductList());
            PickPhotoCommand = ReactiveCommand.CreateFromTask(PickPhotoAsync);

            if (_editing != null)
            {
                // РЕЖИМ РЕДАКТИРОВАНИЯ - подгружаем поля из товара
                Article = _editing.Article;
                Name = _editing.ProductName;
                Description = _editing.Description ?? string.Empty;
                PriceText = _editing.Price.ToString();
                DiscountText = _editing.Discount.ToString();
                StockText = _editing.StockQuantity.ToString();
                _photo = _editing.Photo ?? string.Empty;
                SelectedCategory = Categories.FirstOrDefault(c => c.IdCategory == _editing.IdCategory);
                SelectedSupplier = Suppliers.FirstOrDefault(s => s.IdSupplier == _editing.IdSupplier);
                SelectedManufacturer = Manufacturers.FirstOrDefault(m => m.IdManufacturer == _editing.IdManufacturer);
                SelectedUnit = Units.FirstOrDefault(u => u.IdUnit == _editing.IdUnit);
            }
            else
            {
                // РЕЖИМ ДОБАВЛЕНИЯ - значения по умолчанию
                SelectedCategory = Categories.FirstOrDefault();
                SelectedSupplier = Suppliers.FirstOrDefault();
                SelectedManufacturer = Manufacturers.FirstOrDefault();
                SelectedUnit = Units.FirstOrDefault();
            }
        }

        public string Title => _editing == null ? "Добавление товара" : "Редактирование товара";
        public bool IsEditMode => _editing != null;   // артикул только для чтения при редактировании

        public List<Category> Categories { get; }
        public List<Supplier> Suppliers { get; }
        public List<Manufacturer> Manufacturers { get; }
        public List<Unit> Units { get; }

        public string Article { get => _article; set => this.RaiseAndSetIfChanged(ref _article, value); }
        public string Name { get => _name; set => this.RaiseAndSetIfChanged(ref _name, value); }
        public string Description { get => _description; set => this.RaiseAndSetIfChanged(ref _description, value); }
        public string PriceText { get => _priceText; set => this.RaiseAndSetIfChanged(ref _priceText, value); }
        public string DiscountText { get => _discountText; set => this.RaiseAndSetIfChanged(ref _discountText, value); }
        public string StockText { get => _stockText; set => this.RaiseAndSetIfChanged(ref _stockText, value); }

        public Category? SelectedCategory { get => _selectedCategory; set => this.RaiseAndSetIfChanged(ref _selectedCategory, value); }
        public Supplier? SelectedSupplier { get => _selectedSupplier; set => this.RaiseAndSetIfChanged(ref _selectedSupplier, value); }
        public Manufacturer? SelectedManufacturer { get => _selectedManufacturer; set => this.RaiseAndSetIfChanged(ref _selectedManufacturer, value); }
        public Unit? SelectedUnit { get => _selectedUnit; set => this.RaiseAndSetIfChanged(ref _selectedUnit, value); }

        // Путь к фото для предпросмотра
        public string PhotoPath
        {
            get
            {
                if (!string.IsNullOrEmpty(_photo))
                {
                    var p = Path.Combine(AppContext.BaseDirectory, "Assets", _photo);
                    if (File.Exists(p)) return p;
                }
                return Path.Combine(AppContext.BaseDirectory, "Assets", "picture.png");
            }
        }

        public ReactiveCommand<RUnit, RUnit> SaveCommand { get; }
        public ReactiveCommand<RUnit, RUnit> BackCommand { get; }
        public ReactiveCommand<RUnit, RUnit> PickPhotoCommand { get; }

        // Выбор и загрузка фото с ресайзом до 300x200
        private async System.Threading.Tasks.Task PickPhotoAsync()
        {
            var owner = App.MainWindow;
            if (owner == null) return;

            var dlg = new Avalonia.Controls.OpenFileDialog
            {
                Title = "Выберите изображение",
                AllowMultiple = false,
                Filters = new List<Avalonia.Controls.FileDialogFilter>
                {
                    new() { Name = "Изображения", Extensions = { "jpg", "jpeg", "png" } }
                }
            };

            var result = await dlg.ShowAsync(owner);
            if (result == null || result.Length == 0) return;

            try
            {
                string sourcePath = result[0];
                string assetsDir = Path.Combine(AppContext.BaseDirectory, "Assets");
                Directory.CreateDirectory(assetsDir);

                // Новое имя файла - по артикулу
                string ext = Path.GetExtension(sourcePath);
                string newFileName = $"{(string.IsNullOrEmpty(Article) ? Guid.NewGuid().ToString("N") : Article)}{ext}";
                string destPath = Path.Combine(assetsDir, newFileName);

                // Удаляем старое фото при замене (требование задания)
                if (!string.IsNullOrEmpty(_photo))
                {
                    var oldPath = Path.Combine(assetsDir, _photo);
                    if (File.Exists(oldPath) && _photo != newFileName)
                    {
                        try { File.Delete(oldPath); } catch { /* игнор */ }
                    }
                }

                // Ресайз до 300x200 и сохранение
                using (var image = SixLabors.ImageSharp.Image.Load(sourcePath))
                {
                    image.Mutate(x => x.Resize(new ResizeOptions
                    {
                        Size = new Size(300, 200),
                        Mode = ResizeMode.Max
                    }));
                    image.Save(destPath);
                }

                _photo = newFileName;
                this.RaisePropertyChanged(nameof(PhotoPath));
            }
            catch (Exception ex)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Error, $"Ошибка загрузки фото: {ex.Message}");
            }
        }

        // Сохранение с валидацией
        private async System.Threading.Tasks.Task SaveAsync()
        {
            var owner = App.MainWindow;
            if (owner == null) return;

            // === ВАЛИДАЦИЯ ===
            if (string.IsNullOrWhiteSpace(Article))
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning, "Укажите артикул товара.");
                return;
            }
            if (string.IsNullOrWhiteSpace(Name))
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning, "Укажите наименование товара.");
                return;
            }
            if (!decimal.TryParse(PriceText, out var price) || price < 0)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning,
                    "Цена должна быть числом и не может быть отрицательной.");
                return;
            }
            if (!int.TryParse(StockText, out var stock) || stock < 0)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning,
                    "Количество должно быть целым числом и не может быть отрицательным.");
                return;
            }
            if (!int.TryParse(DiscountText, out var discount) || discount < 0 || discount > 100)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning,
                    "Скидка должна быть числом от 0 до 100.");
                return;
            }
            if (SelectedCategory == null || SelectedSupplier == null ||
                SelectedManufacturer == null || SelectedUnit == null)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Warning,
                    "Заполните все выпадающие списки (категория, поставщик, производитель, единица).");
                return;
            }

            try
            {
                if (_editing == null)
                {
                    // Проверка уникальности артикула при добавлении
                    if (_db.ArticleExists(Article.Trim()))
                    {
                        await MessageBoxService.ShowAsync(owner, DialogType.Warning,
                            "Товар с таким артикулом уже существует. Укажите другой артикул.");
                        return;
                    }

                    var product = new Product
                    {
                        Article = Article.Trim(),
                        ProductName = Name.Trim(),
                        Price = price,
                        Discount = discount,
                        StockQuantity = stock,
                        Description = Description,
                        Photo = _photo,
                        IdCategory = SelectedCategory.IdCategory,
                        IdSupplier = SelectedSupplier.IdSupplier,
                        IdManufacturer = SelectedManufacturer.IdManufacturer,
                        IdUnit = SelectedUnit.IdUnit
                    };
                    _db.AddProduct(product);
                    await MessageBoxService.ShowAsync(owner, DialogType.Info, "Товар успешно добавлен.");
                }
                else
                {
                    var product = new Product
                    {
                        Article = _editing.Article,  // артикул не меняется
                        ProductName = Name.Trim(),
                        Price = price,
                        Discount = discount,
                        StockQuantity = stock,
                        Description = Description,
                        Photo = _photo,
                        IdCategory = SelectedCategory.IdCategory,
                        IdSupplier = SelectedSupplier.IdSupplier,
                        IdManufacturer = SelectedManufacturer.IdManufacturer,
                        IdUnit = SelectedUnit.IdUnit
                    };
                    _db.UpdateProduct(product);
                    await MessageBoxService.ShowAsync(owner, DialogType.Info, "Изменения сохранены.");
                }

                _main.BackToProductList();
            }
            catch (Exception ex)
            {
                await MessageBoxService.ShowAsync(owner, DialogType.Error, $"Ошибка сохранения: {ex.Message}");
            }
        }
    }
}
