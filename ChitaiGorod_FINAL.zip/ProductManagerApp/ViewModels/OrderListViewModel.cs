using ChitaiGorodApp.Entities;
using ChitaiGorodApp.Services;
using ReactiveUI;
using System.Collections.ObjectModel;
using RUnit = System.Reactive.Unit;

namespace ChitaiGorodApp.ViewModels
{
    // Просмотр заказов (для менеджера и администратора)
    public class OrderListViewModel : ViewModelBase
    {
        private readonly MainWindowViewModel _main;
        private readonly DatabaseService _db;

        public OrderListViewModel(MainWindowViewModel main)
        {
            _main = main;
            _db = new DatabaseService();
            BackCommand = ReactiveCommand.Create(() => _main.BackToProductList());

            var orders = _db.GetAllOrders();
            Orders = new ObservableCollection<Order>(orders);
        }

        public ObservableCollection<Order> Orders { get; }
        public ReactiveCommand<RUnit, RUnit> BackCommand { get; }
    }
}
